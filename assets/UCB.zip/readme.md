# mysterious

将doggyred跑了一下红图，传教士的面部红晕也改成彩色了。
对0.5.2.8应该可以完美适配了。

原仓库：https://github.com/site098/mysterious
感谢你的工作。
